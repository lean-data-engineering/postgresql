SELECT
	*
FROM
	CUSTOMERS;

INSERT INTO
	customers (first_name, last_name, email, age)
VALUES
	('Adnan', 'Waheed', 'a@b.com', 40);

	